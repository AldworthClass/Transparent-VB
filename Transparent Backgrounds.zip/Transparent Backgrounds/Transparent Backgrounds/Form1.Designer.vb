﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTransparent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTransparent))
        Me.tmrMoveMeteor = New System.Windows.Forms.Timer(Me.components)
        Me.tmrUFORight = New System.Windows.Forms.Timer(Me.components)
        Me.tmrUFOLeft = New System.Windows.Forms.Timer(Me.components)
        Me.tmrUFODown = New System.Windows.Forms.Timer(Me.components)
        Me.tmrUFOUp = New System.Windows.Forms.Timer(Me.components)
        Me.UFOHealth = New System.Windows.Forms.ProgressBar()
        Me.tmrPaintTimer = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'tmrMoveMeteor
        '
        Me.tmrMoveMeteor.Enabled = True
        Me.tmrMoveMeteor.Interval = 50
        '
        'tmrUFORight
        '
        Me.tmrUFORight.Interval = 50
        '
        'tmrUFOLeft
        '
        Me.tmrUFOLeft.Interval = 50
        '
        'tmrUFODown
        '
        Me.tmrUFODown.Interval = 50
        '
        'tmrUFOUp
        '
        Me.tmrUFOUp.Interval = 50
        '
        'UFOHealth
        '
        Me.UFOHealth.Location = New System.Drawing.Point(12, 469)
        Me.UFOHealth.Name = "UFOHealth"
        Me.UFOHealth.Size = New System.Drawing.Size(171, 23)
        Me.UFOHealth.TabIndex = 0
        Me.UFOHealth.Value = 100
        '
        'tmrPaintTimer
        '
        Me.tmrPaintTimer.Enabled = True
        Me.tmrPaintTimer.Interval = 50
        '
        'frmTransparent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(855, 504)
        Me.Controls.Add(Me.UFOHealth)
        Me.DoubleBuffered = True
        Me.Name = "frmTransparent"
        Me.Text = "Transparent Backgrounds"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents tmrMoveMeteor As Timer
    Friend WithEvents tmrUFORight As Timer
    Friend WithEvents tmrUFOLeft As Timer
    Friend WithEvents tmrUFODown As Timer
    Friend WithEvents tmrUFOUp As Timer
    Friend WithEvents UFOHealth As ProgressBar
    Friend WithEvents tmrPaintTimer As Timer
End Class
