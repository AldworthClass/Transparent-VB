﻿Public Class frmTransparent
    Dim ufo As Bitmap   'Will stores the image of the UFO that we will paint
    Dim ufoBounds As New Rectangle(10, 10, 111, 81) 'Stores the position and size of the Bitmap we are going to paint
    'Rectangle(x-cord, y-cord, width, height)
    Dim intUFOSpeed As Integer

    Dim meteor As Bitmap
    Dim meteorBounds As New Rectangle(400, 100, 65, 100)
    Dim intMeteorSpeed As Integer

    Private Sub frmTransparent_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ufo = New Bitmap(My.Resources.ufo_with_magenta_background)  'Creates Bitmap with image from resources
        ufo.MakeTransparent(Color.Magenta)  'Magenta has an RGB value of (255, 0, 255)
        intUFOSpeed = 2

        meteor = New Bitmap(My.Resources.meteor_with_magenta_backgro)
        meteor.MakeTransparent(Color.Magenta)
        intMeteorSpeed = 2
    End Sub

    'This is where we draw our Bitmaps to the Form.  We will need to call this method using Me.Refresh() to update the Form with the correct locations of our Bitmaps
    Private Sub frmTransparent_Paint(sender As Object, e As PaintEventArgs) Handles Me.Paint
        Dim g As Graphics = e.Graphics
        g.DrawImage(ufo, ufoBounds)         'Draws the Bitmap UFO in the Rectangle ufoBounds
        g.DrawImage(meteor, meteorBounds)
    End Sub


    Private Sub tmrMoveMeteor_Tick(sender As Object, e As EventArgs) Handles tmrMoveMeteor.Tick
        'adds intMeteorSpeed to the y-coordinate of its bounding Rectangle
        meteorBounds.Y += intMeteorSpeed


        If meteorBounds.Top > Me.ClientSize.Height Then 'Detects if meteor goes off bottom of Form
            meteorBounds.Y = -1 * meteorBounds.Height   'If meteor goes off bottom of screen, it is places just above top
        End If

        'Collision with UFO
        If meteorBounds.IntersectsWith(ufoBounds) Then
            If UFOHealth.Value > 0 Then
                UFOHealth.Value -= 1    'Decreases health of any left
            Else
                'Shuts down game upon shields runing out
                tmrMoveMeteor.Enabled = False
                tmrPaintTimer.Enabled = False
                MsgBox("Game Over", MsgBoxStyle.OkOnly, "Sorry")
                Me.Close()
            End If
        End If
    End Sub

    Private Sub frmTransparent_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown

        'Starts movement Timers when keys are pressed
        If e.KeyCode = Keys.Right Then
            tmrUFORight.Enabled = True
        ElseIf e.KeyCode = Keys.Left Then
            tmrUFOLeft.Enabled = True
        ElseIf e.KeyCode = Keys.Up Then
            tmrUFOUp.Enabled = True
        ElseIf e.KeyCode = Keys.Down Then
            tmrUFODown.Enabled = True
        End If
    End Sub



    Private Sub tmrUFORight_Tick(sender As Object, e As EventArgs) Handles tmrUFORight.Tick
        ufoBounds.X += intUFOSpeed
    End Sub
             Private Sub tmrUFOUp_Tick(sender As Object, e As EventArgs) Handles tmrUFOUp.Tick
        ufoBounds.Y -= intUFOSpeed
    End Sub

    Private Sub tmrUFODown_Tick(sender As Object, e As EventArgs) Handles tmrUFODown.Tick
        ufoBounds.Y += intUFOSpeed
    End Sub

    Private Sub tmrUFOLeft_Tick(sender As Object, e As EventArgs) Handles tmrUFOLeft.Tick
        ufoBounds.X -= intUFOSpeed
    End Sub

    'This timer re-paints the Form
    Private Sub tmrPaintTimer_Tick(sender As Object, e As EventArgs) Handles tmrPaintTimer.Tick
        Me.Refresh()   'Re-paints the Form
    End Sub

    Private Sub frmTransparent_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp

        'Stops Timers when keys are released
        If e.KeyCode = Keys.Right Then
            tmrUFORight.Enabled = False
        ElseIf e.KeyCode = Keys.Left Then
            tmrUFOLeft.Enabled = False
        ElseIf e.KeyCode = Keys.Up Then
            tmrUFOUp.Enabled = False
        ElseIf e.KeyCode = Keys.Down Then
            tmrUFODown.Enabled = False
        End If
    End Sub


End Class
